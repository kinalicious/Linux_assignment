#include<stdio.h>
#include<stdlib.h>
#include<string.h>

int main()
{
	int num, i, j, k;
	char ch, str[100], rev[100];

	FILE *infile;
	infile = fopen("Input.txt","r");
	FILE *outfile;
	outfile = fopen("binOut.bin","wb");
	/*FILE *infile2;
	infile2 = fopen("binOut.bin","rb");*/
	FILE *outfile2;
	outfile2 = fopen("reverseOut.txt","w");

	//error handling
	if (!infile){
		printf("unable to input file!\n");
		return 0;
	}

	while(!feof(infile)){
		fread(&ch,sizeof(char),1,infile);
		num = ch;
		fwrite(&num,sizeof(char),1,outfile);
	}

	if (!infile2){
		printf("unable to input bin file!\n");
		return 0;
	}
	while(!feof(infile2)){
		for(i =0 ; str[i] !=0; i++)
		{
			k = i-1;
		}
		for (j=0; j<=i-1; j++)
		{
			rev[j] = str[k];
			k--;
		}
		fwrite(&rev,sizeof(char),1,outfile2);
	}
	fclose(infile);
	fclose(outfile);
	fclose(infile2);
	fclose(outfile2);

}


